/* Árvores de Busca Binária */
#include "arv.h"

no * busca (no * raiz, char* x);
no * maximo (no * raiz);
no * insereABB (no * raiz, char* x,int linha);
no * removeABB (no * raiz, char* x);
int procura(no* raiz, char*x);